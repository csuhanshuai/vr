#! /bin/sh
#��������
AppName=libpsc_eaton_dev
LibVersion=0.0.6
# ��¼����B9����ʱ�ļ�
B9_temp_file=/tmp/update/b9_update_record.emap
excute_shell_order()
{
	for try_cnt in `seq 1 10`
	do
		$1
		retcode=$?
		if [ $retcode -eq 0 ];then
			return 0
		fi
		echo "`date` [APP update] INFO: can not excute shell: \"$1\", retcode: $retcode"
		usleep 100000
	done
	echo "`date` [APP update]  ERR: can not excute shell: \"$1\", retcode: $retcode"
	echo "ERR: can not excute shell: \"$1\", retcode: $retcode"
	exit 5
}
pidof app_arm > /dev/null 2>&1
if [ $? -eq 0 ]; then
	RUNNING_APP=`cat /proc/\`pidof app_arm\`/cmdline`
else
	#Ĭ�ϵ�ǰ���е���app1�������Ϳ���Ĭ������app0
	RUNNING_APP="/mnt/app_bin1/bin_arm/app_arm"
fi
#determine which partion to update
echo $RUNNING_APP | grep app_bin0 > /dev/null 2>&1
if [ $? -eq 0 ];then
	TARGET_PATH=/mnt/app_bin1/bin_arm/apploadso
	OTHER_TARGET_PATH=/mnt/app_bin0/bin_arm/apploadso
else
	TARGET_PATH=/mnt/app_bin0/bin_arm/apploadso
	OTHER_TARGET_PATH=/mnt/app_bin1/bin_arm/apploadso
fi
if [ ! -d $TARGET_PATH ];then
	mkdir $TARGET_PATH
fi
TEMPPATH="/tmp/update/temp"
# ����������:��һ�������͡�1 ��/tem/upload�����ļ�,2 ��/mnt/app_bin*/bin_arm�����ļ�;; 3:ɾ���ļ�����,ж��ʱʹ�á�
if [ $# -eq 1 ]; then
	if [ $1 == "1" ]; then
		INPUTPATH=$TEMPPATH
		echo -e $AppName>>$B9_temp_file
		echo "`date` [SOACM update]  INFO: Record $AppName" >> /home/update/update.log
	elif [ $1 == "2" ]; then
		INPUTPATH=$OTHER_TARGET_PATH
	elif [ $1 == "3" ]; then
		INPUTPATH=$OTHER_TARGET_PATH
		if [ -e ${INPUTPATH}/${AppName}.emap ];then
			echo "`date` [SOACM Uninstall] INFO:${AppName}.emap" >> /home/update/update.log
			excute_shell_order "rm -rf ${AppName}.emap"
		fi
		if [ -e ${INPUTPATH}/${AppName}.so.${LibVersion} ];then
			echo "`date` [SOACM Uninstall] INFO:${AppName}.so.${LibVersion}" >> /home/update/update.log
			excute_shell_order "rm -rf ${AppName}.so.${LibVersion}"
		fi
		if [ -e ${INPUTPATH}/${AppName}.sh ];then
			echo "`date` [SOACM Uninstall] INFO:${AppName}.sh" >> /home/update/update.log
			excute_shell_order "rm -rf ${INPUTPATH}/${AppName}.sh"
		fi
		echo "SOOK"
		return 0
	fi
	if [ ! -e ${INPUTPATH}/${AppName}.sh ];then
		echo "`date` [SOACM update] INFO Err :${AppName}.sh" >> /home/update/update.log
		return 1
	fi
	if [ ! -e ${INPUTPATH}/${AppName}.so.${LibVersion} ];then
		echo "`date` [SOACM update] INFO Err :${AppName}.so.${LibVersion}" >> /home/update/update.log
		return 1
	fi
	if [ ! -e ${INPUTPATH}/${AppName}.emap ];then
		echo "`date` [SOACM update] INFO Err :${AppName}.emap" >> /home/update/update.log
		return 1
	fi
	excute_shell_order "cp	${INPUTPATH}/${AppName}.sh	$TARGET_PATH"
	excute_shell_order "cp	${INPUTPATH}/${AppName}.so.${LibVersion}	$TARGET_PATH"
	excute_shell_order "cp	${INPUTPATH}/${AppName}.emap	$TARGET_PATH"
	echo "`date` [SOACM update]  INFO: Exec $AppName" >> /home/update/update.log
fi
# ���û�в���������
if [ $# -lt 1 ]; then
	echo "NO INPUT PARA"
	echo $#
	echo "`date` [SOACM update]  INFO: No Input Para" >> /home/update/update.log
	return 0
fi
echo "`date` [APP LOAD] INFO: app load success"
echo "SOOK"
return 0
